# ETHBT standalone site

Built only from the currently readable ETHBT source at https://ethama.de/.

Intentionally omitted: phone, address, hours, reviews, prices, company history, named partners, audit provider/report details, and any unsupported claims.

`index.html` is self-contained apart from Google Fonts.
